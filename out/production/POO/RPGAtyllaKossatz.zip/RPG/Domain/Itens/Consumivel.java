package RPG.Domain.Itens;


public abstract class Consumivel extends ItemHeroi {


  public Consumivel(String nome, int precoMoedasOuro) {
    super(nome, precoMoedasOuro);
  }


  @Override
  public void mostrarDetalhes() {
    super.mostrarDetalhes();

  }
}
